package tdtu.edu.un.WG26;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Wg26Application {

	public static void main(String[] args) {
		SpringApplication.run(Wg26Application.class, args);
	}

}
