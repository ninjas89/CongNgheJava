package tdtu.edu.un.WG26;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Wg26ApplicationTests {

	@Test
	void contextLoads() {
	}

}
